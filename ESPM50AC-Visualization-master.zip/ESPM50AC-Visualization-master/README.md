# UC Berkeley ESPM50AC Visualization
Shows Ethnic Distributions along Coastal areas in response to Natural Disasters

In this project, we worked to create a visualization that engaged with conepts from this course such as ethics, ethnic distributions, and natural disasters in an easy to view manner.
